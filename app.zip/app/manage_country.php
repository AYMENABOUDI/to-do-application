<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class manage_country extends Model
{
            protected $table = 'manage_country';
           protected $fillable = [
        'name'
    ];
}